

 	<footer id="footer">
      Copyright © 2019-2020 4K Company.All rights reserved.
    </footer>

