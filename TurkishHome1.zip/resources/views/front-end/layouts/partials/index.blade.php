@extends('front-end.layouts.master')

@section('content')

<!-- ===Images Slider=== -->
@include('front-end.layouts.partials.images-slider')

@endsection