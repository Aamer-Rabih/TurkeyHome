<div class="contact">
  <footer>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 ">
        <div class="justfy-content-center">
          <h5 ><strong>معلومات التواصل</strong></h5>
          <p>(888) 888-8888<br>email@nuno.com</p>
          <a href="" target="_blank"><i class="fa fa-facebook-square icon" aria-hidden="true"></i></a>
          <a href="" target="_blank"><i class="fa fa-twitter-square icon" aria-hidden="true"></i></a>
          <a href="" target="_blank"><i class="fa fa-instagram icon" aria-hidden="true"></i></a>
          <a href="" target="_blank"><i class="fa fa-telegram icon" aria-hidden="true"></i></a>
      </div>
        </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <img src="{{asset('imgs/logo1.png')}}">
      </div>
    </div>
    <hr class="socket">
   

 	<div id="bottom-bar">
      Copyright © 2019-2020 4K Company.All rights reserved.
    </footer>


</div>
</div>