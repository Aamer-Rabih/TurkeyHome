@extends('front-end.layouts.master')

@section('content')

<!-- ===Image Slider=== -->
@include('front-end.home.partials.image-slider')

<!-- ===ShowLessons Carousel=== -->
@include('front-end.home.partials.showLessons-carousel')

<!-- ===ShowLessons Carousel=== -->
@include('front-end.home.partials.studentThanks-carousel')

@endsection