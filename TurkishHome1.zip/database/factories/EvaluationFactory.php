<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Evaluation;
use Faker\Generator as Faker;

$factory->define(Evaluation::class, function (Faker $faker) {
    return [
        //
    ];
});
