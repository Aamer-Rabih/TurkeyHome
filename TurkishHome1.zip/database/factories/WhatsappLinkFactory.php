<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\WhatsappLink;
use Faker\Generator as Faker;

$factory->define(WhatsappLink::class, function (Faker $faker) {
    return [
        //
    ];
});
