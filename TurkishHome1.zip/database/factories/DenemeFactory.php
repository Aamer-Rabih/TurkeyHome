<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Deneme;
use Faker\Generator as Faker;

$factory->define(Deneme::class, function (Faker $faker) {
    return [
        //
    ];
});
