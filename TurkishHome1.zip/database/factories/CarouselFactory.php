<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Carousel;
use Faker\Generator as Faker;

$factory->define(Carousel::class, function (Faker $faker) {
    return [
        //
    ];
});
