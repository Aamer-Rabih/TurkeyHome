<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\FreeReason;
use Faker\Generator as Faker;

$factory->define(FreeReason::class, function (Faker $faker) {
    return [
        //
    ];
});
