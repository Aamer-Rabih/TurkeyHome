<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\StudentThank;
use Faker\Generator as Faker;

$factory->define(StudentThank::class, function (Faker $faker) {
    return [
        //
    ];
});
