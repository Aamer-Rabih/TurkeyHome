<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Advice;
use Faker\Generator as Faker;

$factory->define(Advice::class, function (Faker $faker) {
    return [
        //
    ];
});
